package cn.smbms.tools;

//常量类
public class Constants {
	public  static final String USER_SESSION = "userSession";
	public  static final String ADMAIN_SESSION = "adminsession";
	public final static String SYS_MESSAGE = "message";
	public final static int pageSize = 5;
}
